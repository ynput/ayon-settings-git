"""Forward HTTP requests to the service and stream responses back."""

from __future__ import annotations

import asyncio
import contextlib
from typing import TYPE_CHECKING
from urllib.parse import unquote_plus

from starlette.responses import JSONResponse, Response, StreamingResponse

from .hub import END_FRAMES, Route, TunnelClosedError, TunnelHub
from .protocol import (
    INITIAL_WINDOW,
    USER_HEADER,
    Frame,
    FrameType,
    chunks,
    filter_headers,
)

if TYPE_CHECKING:
    from collections.abc import AsyncIterator

    from starlette.requests import Request


# How long to wait for the service to start answering a request.
RESPONSE_START_TIMEOUT = 60.0

# Credit is returned to the service in batches of at least this many
# bytes, rather than one WINDOW frame per chunk.
WINDOW_UPDATE_THRESHOLD = INITIAL_WINDOW // 4

# Caller credentials never reach the service. The server authenticates the
# caller and passes only the user name (``USER_HEADER``); the service calls
# AYON with its own service key and ``x-as-user``. A client-sent
# ``USER_HEADER`` is dropped, so it can't be used to impersonate anyone.
CREDENTIAL_HEADERS = frozenset({
    "authorization",
    "cookie",
    "x-api-key",
    "x-as-user",
    USER_HEADER,
})

# How long to keep trying to tell the service a request was cancelled.
CANCEL_TIMEOUT = 5.0

# Tasks sending CANCEL, referenced until done so they aren't collected.
_background: set[asyncio.Task[None]] = set()

# AYON also accepts an access token in the query (``?token=``).
CREDENTIAL_QUERY_PARAMS = frozenset({"token"})

# The service must not set cookies on the AYON server origin.
BLOCKED_RESPONSE_HEADERS = frozenset({"set-cookie"})


def _error(status: int, detail: str) -> Response:
    return JSONResponse({"detail": detail}, status_code=status)


def _unavailable() -> Response:
    response = _error(503, "Settings Git service is not connected")
    response.headers["Retry-After"] = "5"
    return response


class _ClientGoneError(Exception):
    """The client disconnected before the service answered."""


async def _disconnected(request: Request) -> None:
    """Return once the client disconnects.

    Only for after the request body is read: the server is not obliged
    to cancel the handler when the client goes away, so the only sign of
    it is an ``http.disconnect`` message.
    """
    with contextlib.suppress(Exception):
        if (await request.receive())["type"] == "http.disconnect":
            return
    # Anything else (e.g. a middleware replaying the body) can't tell us
    # about the client: leave it to the response timeout rather than spin.
    await asyncio.Event().wait()


async def _first_frame(request: Request, route: Route) -> Frame | None:
    """Wait for the service to start answering.

    Returns:
        The first response frame, or ``None`` if the tunnel closed.

    Raises:
        TimeoutError: If the service took too long.
        _ClientGoneError: If the client disconnected first.

    """
    response = asyncio.ensure_future(route.receive())
    disconnect = asyncio.ensure_future(_disconnected(request))
    try:
        done, _ = await asyncio.wait(
            {response, disconnect},
            timeout=RESPONSE_START_TIMEOUT,
            return_when=asyncio.FIRST_COMPLETED,
        )
    finally:
        # Not awaited: both are safe to abandon, and awaiting here would
        # be cancelled too if this request is being cancelled.
        response.cancel()
        disconnect.cancel()
    if response in done:
        return response.result()
    if disconnect in done:
        raise _ClientGoneError
    raise TimeoutError


def _service_query(request: Request) -> str:
    """Return the request's query string without credentials.

    Other parameters are kept exactly as sent.

    Returns:
        The query string for the service.

    """
    return "&".join(
        part
        for part in request.url.query.split("&")
        if part
        and unquote_plus(part.partition("=")[0]) not in CREDENTIAL_QUERY_PARAMS
    )


class _ProxiedRequest:
    """One HTTP request forwarded through a tunnel."""

    def __init__(self, route: Route, path: str) -> None:
        self.route = route
        self.path = path
        self.finished = False

    async def forward(self, request: Request, user_name: str) -> None:
        """Send the request line, headers and body to the service."""
        headers = filter_headers(
            list(request.headers.items()), drop=CREDENTIAL_HEADERS
        )
        headers.append((USER_HEADER, user_name))
        stream_id = self.route.stream_id
        await self.route.send(
            Frame.with_json(
                FrameType.REQUEST_START,
                stream_id,
                {
                    "method": request.method,
                    "path": self.path,
                    "query": _service_query(request),
                    "headers": headers,
                },
            )
        )
        async for body in request.stream():
            for chunk in chunks(body):
                await self.route.send(
                    Frame(FrameType.REQUEST_BODY, stream_id, chunk)
                )
        await self.route.send(Frame(FrameType.REQUEST_END, stream_id))

    def cancel(self) -> None:
        """Close the route and tell the service, unless it finished.

        Usually runs while the request is being cancelled (the client went
        away), where any await - e.g. publishing to Redis - would be
        cancelled too. So CANCEL is sent from a task of its own.
        """
        self.route.close()
        if not self.finished:
            task = asyncio.create_task(self._send_cancel())
            _background.add(task)
            task.add_done_callback(_background.discard)

    async def _send_cancel(self) -> None:
        with contextlib.suppress(Exception):
            async with asyncio.timeout(CANCEL_TIMEOUT):
                await self.route.send(
                    Frame(FrameType.CANCEL, self.route.stream_id)
                )

    async def respond(self, first: Frame | None) -> Response:
        """Turn the service's first frame into the client response.

        Returns:
            A streaming response, or 502 if the service failed.

        """
        if first is None:
            self.route.close()
            return _error(502, "Service disconnected")
        if first.type is FrameType.RESPONSE_ERROR:
            self.route.close()
            message = first.json().get("message", "unknown error")
            return _error(502, f"Service error: {message}")
        if first.type is not FrameType.RESPONSE_START:
            self.cancel()
            return _error(
                502, f"Unexpected tunnel frame {first.type.name}"
            )

        start = first.json()
        response = StreamingResponse(
            self._body(), status_code=int(start.get("status", 502))
        )
        for name, value in filter_headers(
            [(str(h[0]), str(h[1])) for h in start.get("headers", [])],
            drop=BLOCKED_RESPONSE_HEADERS,
        ):
            response.headers.append(name, value)
        # Keep reverse proxies (nginx, ingress) from buffering SSE streams.
        response.headers["X-Accel-Buffering"] = "no"
        return response

    async def _body(self) -> AsyncIterator[bytes]:
        try:
            # _payloads needs no cleanup, so it may be left unclosed.
            async for payload in self._payloads():
                yield payload
        finally:
            # Runs on completion and when the client disconnects
            # mid-stream; only the latter sends CANCEL.
            self.cancel()

    async def _payloads(self) -> AsyncIterator[bytes]:
        consumed = 0
        while True:
            frame = await self.route.receive()
            if frame is None:
                # Tunnel gone or stream dropped: the client sees a
                # truncated body; CANCEL stops the service if it is
                # still there.
                return
            if frame.type in END_FRAMES:
                # The status is already sent; on error the client sees a
                # truncated body.
                self.finished = True
                return
            if frame.type is not FrameType.RESPONSE_BODY:
                continue
            # Resumes once the chunk is written to the client, so credit
            # follows the client's pace.
            yield frame.payload
            consumed += len(frame.payload)
            if consumed >= WINDOW_UPDATE_THRESHOLD:
                try:
                    await self.route.send(
                        Frame.window(self.route.stream_id, consumed)
                    )
                except TunnelClosedError:
                    return
                consumed = 0


async def proxy_request(
    request: Request, hub: TunnelHub, user_name: str, path: str
) -> Response:
    """Forward an HTTP request to ``path`` of a connected service's app.

    ``request`` must already be authenticated as ``user_name``. The service
    acts on AYON as that user (Service API key + ``x-as-user``). The query
    string is forwarded as is, without credentials.

    Returns:
        The service's response, streamed as it is produced, or
        502/503/504 if the tunnel fails.

    """
    route = await hub.open_route()
    if route is None:
        return _unavailable()

    proxied = _ProxiedRequest(route, path)
    try:
        await proxied.forward(request, user_name)
        first = await _first_frame(request, route)
    except TunnelClosedError:
        route.close()
        return _error(502, "Service disconnected")
    except TimeoutError:
        proxied.cancel()
        return _error(504, "Service did not respond")
    except _ClientGoneError:
        proxied.cancel()
        # Nobody reads it; 499 shows up in access logs as "client closed".
        return _error(499, "Client disconnected")
    except BaseException:
        # The client went away while the request was being forwarded.
        proxied.cancel()
        raise
    return await proxied.respond(first)
